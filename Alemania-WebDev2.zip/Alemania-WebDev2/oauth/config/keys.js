{module.exports = {
    google:{
        clientID: '279895077427-frc42748q8b7v3s7q59ft4quuuer2mpo.apps.googleusercontent.com', 
        clientSecret: 'm6HcLxas4Eq4O4P4VuHzNpKA'
    },
    postgresdb:
        {
        user: 'edwqynuvztudep',
        host: 'ec2-52-7-39-178.compute-1.amazonaws.com',
        database: 'dflpakf9m3d7q4',
        password: '610ad794b9f8aa16a75f2827209b12dd79fc48f141737993a42c404f2c3328c3',
        port:'5432',
        ssl:true,
    },
    session:{
        cookieKey: 'thisismyuniquecookiekey'
    }
};}


